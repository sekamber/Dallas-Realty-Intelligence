
import { GoogleGenAI, Type } from "@google/genai";
import { UserPreferences, MarketData, Report } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const generateMarketReport = async (prefs: UserPreferences): Promise<Report> => {
  const model = 'gemini-3-flash-preview';
  
  const prompt = `
    You are a Dallas real estate market analyst. 
    Analyze the current real estate market for zip code ${prefs.zipCode} in Dallas, TX.
    The user is looking to ${prefs.purpose} a ${prefs.propertyType} with a budget of ${prefs.budget}.
    
    1. Use Google Search to find REAL-TIME data for this specific zip code:
       - Median home price
       - 12-month price trend (%)
       - Average days on market
       - Inventory levels (Low/Medium/High)
       - Estimated monthly rent for a ${prefs.propertyType}
       - School ratings (1-10)
       - Crime/Safety index
    
    2. Calculate these derived scores:
       - Buyer Demand (1-10)
       - Seller Advantage (1-10)
       - Appreciation Outlook for next 12 months
       - Estimated Cap Rate (%)
       - Risk Score (1-10)

    3. Generate a professional, data-driven narrative report and clear strategic recommendations.

    Return the data in a structured format suitable for parsing.
  `;

  const response = await ai.models.generateContent({
    model: model,
    contents: prompt,
    config: {
      tools: [{ googleSearch: {} }],
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          marketData: {
            type: Type.OBJECT,
            properties: {
              zip: { type: Type.STRING },
              neighborhoodName: { type: Type.STRING },
              medianPrice: { type: Type.NUMBER },
              priceTrend12m: { type: Type.NUMBER },
              daysOnMarket: { type: Type.NUMBER },
              inventoryLevel: { type: Type.STRING },
              estimatedRent: { type: Type.NUMBER },
              schoolRating: { type: Type.NUMBER },
              crimeIndex: { type: Type.STRING },
              buyerDemandScore: { type: Type.NUMBER },
              sellerAdvantageScore: { type: Type.NUMBER },
              appreciationOutlook: { type: Type.STRING },
              capRate: { type: Type.NUMBER },
              riskScore: { type: Type.NUMBER },
            },
            required: ["zip", "neighborhoodName", "medianPrice", "priceTrend12m", "daysOnMarket", "inventoryLevel", "estimatedRent", "schoolRating", "crimeIndex", "buyerDemandScore", "sellerAdvantageScore", "appreciationOutlook", "capRate", "riskScore"]
          },
          narrative: { type: Type.STRING },
          recommendations: {
            type: Type.ARRAY,
            items: { type: Type.STRING }
          }
        },
        required: ["marketData", "narrative", "recommendations"]
      }
    }
  });

  const rawText = response.text;
  const parsedData = JSON.parse(rawText);
  
  const sources = response.candidates?.[0]?.groundingMetadata?.groundingChunks?.map((chunk: any) => ({
    title: chunk.web?.title || 'Market Source',
    uri: chunk.web?.uri || '#'
  })) || [];

  return {
    ...parsedData,
    sources
  };
};
