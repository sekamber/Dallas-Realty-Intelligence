
import React from 'react';
import { Report, UserPreferences } from '../types';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line } from 'recharts';
import ScoreMetric from './ScoreMetric';

interface ReportDashboardProps {
  report: Report;
  prefs: UserPreferences;
}

const ReportDashboard: React.FC<ReportDashboardProps> = ({ report, prefs }) => {
  const { marketData, narrative, recommendations, sources } = report;

  // Simulated chart data based on Gemini analysis
  const trendData = [
    { name: '-12M', price: marketData.medianPrice / (1 + (marketData.priceTrend12m / 100)) },
    { name: '-6M', price: marketData.medianPrice / (1 + (marketData.priceTrend12m / 200)) },
    { name: 'Current', price: marketData.medianPrice },
  ];

  const formatCurrency = (val: number) => 
    new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 }).format(val);

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
      {/* Header Info */}
      <div className="bg-white p-8 rounded-2xl shadow-sm border border-slate-100">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div>
            <div className="flex items-center space-x-2 text-blue-600 font-bold mb-1">
              <i className="fa-solid fa-location-dot"></i>
              <span className="uppercase tracking-widest text-xs">Dallas, TX Market Report</span>
            </div>
            <h1 className="text-4xl font-extrabold text-slate-900 leading-tight">
              {marketData.neighborhoodName} <span className="text-slate-400 font-normal">({marketData.zip})</span>
            </h1>
            <p className="text-slate-500 mt-2 max-w-xl">
              Custom analysis for <span className="text-slate-900 font-semibold">{prefs.propertyType}</span> assets. 
              Optimized for <span className="text-blue-600 font-semibold">{prefs.purpose}</span> strategy within {prefs.budget} budget.
            </p>
          </div>
          <div className="flex gap-4 no-print">
            <button 
              onClick={() => window.print()}
              className="flex items-center space-x-2 px-4 py-2 border border-slate-200 rounded-lg text-slate-600 hover:bg-slate-50 transition-all"
            >
              <i className="fa-solid fa-print"></i>
              <span>Export PDF</span>
            </button>
            <button className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-all shadow-md">
              <i className="fa-solid fa-share-nodes"></i>
              <span>Share</span>
            </button>
          </div>
        </div>
      </div>

      {/* KPI Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 text-center">
          <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Median Sale Price</p>
          <p className="text-3xl font-black text-slate-900">{formatCurrency(marketData.medianPrice)}</p>
          <p className={`text-sm mt-1 font-bold ${marketData.priceTrend12m >= 0 ? 'text-emerald-500' : 'text-rose-500'}`}>
            <i className={`fa-solid ${marketData.priceTrend12m >= 0 ? 'fa-arrow-trend-up' : 'fa-arrow-trend-down'} mr-1`}></i>
            {marketData.priceTrend12m > 0 ? '+' : ''}{marketData.priceTrend12m}% YoY
          </p>
        </div>
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 text-center">
          <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Days on Market</p>
          <p className="text-3xl font-black text-slate-900">{marketData.daysOnMarket}</p>
          <p className="text-sm text-slate-500 mt-1 font-medium">Avg. Listing Velocity</p>
        </div>
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 text-center">
          <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Inventory Level</p>
          <p className={`text-3xl font-black ${marketData.inventoryLevel === 'Low' ? 'text-rose-600' : marketData.inventoryLevel === 'High' ? 'text-emerald-600' : 'text-amber-500'}`}>
            {marketData.inventoryLevel}
          </p>
          <p className="text-sm text-slate-500 mt-1 font-medium">Supply Conditions</p>
        </div>
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 text-center">
          <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Est. Monthly Rent</p>
          <p className="text-3xl font-black text-slate-900">{formatCurrency(marketData.estimatedRent)}</p>
          <p className="text-sm text-slate-500 mt-1 font-medium">Yield: {marketData.capRate}% Cap</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Main Content Area */}
        <div className="lg:col-span-2 space-y-8">
          {/* Narrative Section */}
          <div className="bg-white p-8 rounded-2xl shadow-sm border border-slate-100">
            <h3 className="text-xl font-bold text-slate-900 mb-6 flex items-center">
              <i className="fa-solid fa-file-lines text-blue-600 mr-3"></i>
              Executive Summary
            </h3>
            <div className="prose prose-slate max-w-none text-slate-600 leading-relaxed whitespace-pre-wrap">
              {narrative}
            </div>
          </div>

          {/* Visualization Section */}
          <div className="bg-white p-8 rounded-2xl shadow-sm border border-slate-100">
            <h3 className="text-xl font-bold text-slate-900 mb-6 flex items-center">
              <i className="fa-solid fa-chart-line text-blue-600 mr-3"></i>
              Pricing Dynamics (12 Month Trend)
            </h3>
            <div className="h-64 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={trendData}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                  <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 12}} />
                  <YAxis hide domain={['auto', 'auto']} />
                  <Tooltip 
                    formatter={(value: any) => formatCurrency(value)}
                    contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="price" 
                    stroke="#2563eb" 
                    strokeWidth={4} 
                    dot={{ r: 6, fill: '#2563eb', strokeWidth: 2, stroke: '#fff' }}
                    activeDot={{ r: 8 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        {/* Sidebar Analytics */}
        <div className="space-y-6">
          <div className="bg-white p-8 rounded-2xl shadow-sm border border-slate-100">
            <h3 className="text-xl font-bold text-slate-900 mb-6">Market Scores</h3>
            <div className="space-y-4">
              <ScoreMetric label="Buyer Demand" score={marketData.buyerDemandScore} color="text-blue-600" icon="fa-solid fa-user-group" />
              <ScoreMetric label="Seller Advantage" score={marketData.sellerAdvantageScore} color="text-emerald-600" icon="fa-solid fa-hand-holding-dollar" />
              <ScoreMetric label="Risk Index" score={marketData.riskScore} color="text-rose-600" icon="fa-solid fa-triangle-exclamation" />
              <ScoreMetric label="School Quality" score={marketData.schoolRating} color="text-indigo-600" icon="fa-solid fa-graduation-cap" />
            </div>
          </div>

          <div className="bg-slate-900 p-8 rounded-2xl shadow-xl text-white">
            <h3 className="text-xl font-bold mb-4 flex items-center">
              <i className="fa-solid fa-bolt-lightning text-amber-400 mr-3"></i>
              Strategic Advice
            </h3>
            <ul className="space-y-4">
              {recommendations.map((rec, i) => (
                <li key={i} className="flex items-start space-x-3 text-sm text-slate-300">
                  <div className="mt-1.5 w-1.5 h-1.5 rounded-full bg-amber-400 flex-shrink-0"></div>
                  <span>{rec}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Sources Section */}
          <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
            <h3 className="text-sm font-bold text-slate-400 uppercase tracking-widest mb-4">Verification Sources</h3>
            <div className="space-y-2">
              {sources.map((src, i) => (
                <a 
                  key={i} 
                  href={src.uri} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="block text-xs text-blue-600 hover:underline truncate"
                >
                  <i className="fa-solid fa-link mr-1"></i>
                  {src.title}
                </a>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* CTA Footer */}
      <div className="bg-blue-600 p-8 rounded-2xl shadow-lg text-white text-center no-print">
        <h2 className="text-2xl font-bold mb-2">Want to see properties in {marketData.zip}?</h2>
        <p className="text-blue-100 mb-6 max-w-2xl mx-auto">
          We can provide personalized property matches or mortgage scenarios for this neighborhood.
        </p>
        <button className="px-8 py-3 bg-white text-blue-600 font-bold rounded-xl hover:bg-slate-50 transition-all shadow-md">
          Book a Free Consultation
        </button>
      </div>
    </div>
  );
};

export default ReportDashboard;
