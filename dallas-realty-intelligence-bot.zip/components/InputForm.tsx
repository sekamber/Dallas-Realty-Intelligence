
import React from 'react';
import { UserPreferences, PropertyType, UserPurpose } from '../types';

interface InputFormProps {
  onSubmit: (prefs: UserPreferences) => void;
  isLoading: boolean;
}

const InputForm: React.FC<InputFormProps> = ({ onSubmit, isLoading }) => {
  const [formData, setFormData] = React.useState<UserPreferences>({
    zipCode: '75201',
    propertyType: 'SFH',
    purpose: 'Buy',
    budget: '$500,000 - $750,000',
    email: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(formData);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6 bg-white p-8 rounded-2xl shadow-xl border border-slate-100">
      <div className="flex items-center space-x-3 mb-6">
        <div className="p-3 bg-blue-600 rounded-lg text-white">
          <i className="fa-solid fa-house-chimney-search text-xl"></i>
        </div>
        <div>
          <h2 className="text-xl font-bold text-slate-800 tracking-tight">Market Analysis</h2>
          <p className="text-sm text-slate-500">Real-time Dallas intelligence</p>
        </div>
      </div>

      <div className="space-y-4">
        <div>
          <label className="block text-sm font-semibold text-slate-700 mb-1">Dallas Zip Code</label>
          <input
            type="text"
            required
            pattern="[0-9]{5}"
            className="w-full px-4 py-2.5 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all outline-none"
            placeholder="e.g. 75201"
            value={formData.zipCode}
            onChange={(e) => setFormData({ ...formData, zipCode: e.target.value })}
          />
        </div>

        <div>
          <label className="block text-sm font-semibold text-slate-700 mb-1">Property Type</label>
          <select
            className="w-full px-4 py-2.5 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all outline-none"
            value={formData.propertyType}
            onChange={(e) => setFormData({ ...formData, propertyType: e.target.value as PropertyType })}
          >
            <option value="SFH">Single Family Home</option>
            <option value="Condo">Condo / Townhome</option>
            <option value="Multi-Family">Multi-Family</option>
          </select>
        </div>

        <div>
          <label className="block text-sm font-semibold text-slate-700 mb-1">Your Goal</label>
          <div className="grid grid-cols-3 gap-2">
            {(['Buy', 'Sell', 'Invest'] as UserPurpose[]).map((p) => (
              <button
                key={p}
                type="button"
                onClick={() => setFormData({ ...formData, purpose: p })}
                className={`py-2 text-sm font-medium rounded-lg border transition-all ${
                  formData.purpose === p
                    ? 'bg-blue-600 text-white border-blue-600'
                    : 'bg-white text-slate-600 border-slate-200 hover:border-blue-300'
                }`}
              >
                {p}
              </button>
            ))}
          </div>
        </div>

        <div>
          <label className="block text-sm font-semibold text-slate-700 mb-1">Budget Range</label>
          <input
            type="text"
            className="w-full px-4 py-2.5 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all outline-none"
            placeholder="e.g. $600k - $800k"
            value={formData.budget}
            onChange={(e) => setFormData({ ...formData, budget: e.target.value })}
          />
        </div>

        <div>
          <label className="block text-sm font-semibold text-slate-700 mb-1">Email (to send PDF)</label>
          <input
            type="email"
            required
            className="w-full px-4 py-2.5 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all outline-none"
            placeholder="investor@example.com"
            value={formData.email}
            onChange={(e) => setFormData({ ...formData, email: e.target.value })}
          />
        </div>
      </div>

      <button
        type="submit"
        disabled={isLoading}
        className={`w-full py-4 rounded-xl font-bold text-white shadow-lg shadow-blue-200 transform transition-all active:scale-95 ${
          isLoading ? 'bg-slate-400 cursor-not-allowed' : 'bg-blue-600 hover:bg-blue-700'
        }`}
      >
        {isLoading ? (
          <span className="flex items-center justify-center">
            <i className="fa-solid fa-circle-notch fa-spin mr-2"></i>
            Generating Intelligence...
          </span>
        ) : (
          'Generate Market Report'
        )}
      </button>
      
      <p className="text-[10px] text-center text-slate-400 uppercase tracking-widest font-bold">
        Powered by Gemini 3 & Google Search
      </p>
    </form>
  );
};

export default InputForm;
