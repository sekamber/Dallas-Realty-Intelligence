
import React from 'react';

interface ScoreMetricProps {
  label: string;
  score: number; // 1-10
  color: string;
  icon: string;
}

const ScoreMetric: React.FC<ScoreMetricProps> = ({ label, score, color, icon }) => {
  const percentage = Math.min(Math.max(score * 10, 0), 100);
  
  return (
    <div className="bg-slate-50 p-4 rounded-xl border border-slate-100 transition-all hover:shadow-md">
      <div className="flex justify-between items-center mb-2">
        <div className="flex items-center space-x-2">
          <i className={`${icon} ${color}`}></i>
          <span className="text-sm font-semibold text-slate-600 uppercase tracking-tight">{label}</span>
        </div>
        <span className={`text-lg font-bold ${color}`}>{score.toFixed(1)}/10</span>
      </div>
      <div className="h-2 w-full bg-slate-200 rounded-full overflow-hidden">
        <div 
          className={`h-full rounded-full transition-all duration-1000 ease-out`}
          style={{ width: `${percentage}%`, backgroundColor: color.includes('blue') ? '#2563eb' : color.includes('emerald') ? '#059669' : color.includes('rose') ? '#e11d48' : '#64748b' }}
        ></div>
      </div>
    </div>
  );
};

export default ScoreMetric;
