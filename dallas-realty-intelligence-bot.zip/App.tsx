
import React, { useState, useEffect } from 'react';
import { UserPreferences, Report } from './types';
import InputForm from './components/InputForm';
import ReportDashboard from './components/ReportDashboard';
import { generateMarketReport } from './services/geminiService';

const App: React.FC = () => {
  const [report, setReport] = useState<Report | null>(null);
  const [prefs, setPrefs] = useState<UserPreferences | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleGenerate = async (newPrefs: UserPreferences) => {
    setIsLoading(true);
    setError(null);
    setPrefs(newPrefs);
    
    try {
      const data = await generateMarketReport(newPrefs);
      setReport(data);
    } catch (err: any) {
      console.error(err);
      setError('Failed to fetch real-time market data. Please check the zip code and try again.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen pb-20">
      {/* Navigation */}
      <nav className="bg-white border-b border-slate-200 sticky top-0 z-50 no-print">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-2">
              <div className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center text-white shadow-lg shadow-blue-100">
                <i className="fa-solid fa-city"></i>
              </div>
              <span className="text-xl font-black text-slate-900 tracking-tight">DALLAS<span className="text-blue-600">REALTOR</span>.AI</span>
            </div>
            <div className="hidden md:flex space-x-8 text-sm font-semibold text-slate-500">
              <a href="#" className="hover:text-blue-600 transition-colors">Market Pulse</a>
              <a href="#" className="hover:text-blue-600 transition-colors">Investor Tools</a>
              <a href="#" className="hover:text-blue-600 transition-colors">Neighborhoods</a>
              <a href="#" className="text-blue-600 border-b-2 border-blue-600 py-5">Bot Analysis</a>
            </div>
            <div className="flex items-center space-x-4">
              <button className="hidden sm:block text-sm font-bold text-slate-700 hover:text-blue-600">Log In</button>
              <button className="px-4 py-2 bg-slate-900 text-white text-sm font-bold rounded-lg hover:bg-slate-800 transition-all">Get Premium</button>
            </div>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-12">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
          
          {/* Left Column: Form (Sticky on Desktop) */}
          <div className="lg:col-span-4 no-print">
            <div className="lg:sticky lg:top-28">
              <InputForm onSubmit={handleGenerate} isLoading={isLoading} />
              
              {error && (
                <div className="mt-4 p-4 bg-rose-50 border border-rose-100 rounded-xl text-rose-600 text-sm flex items-start space-x-2">
                  <i className="fa-solid fa-circle-exclamation mt-0.5"></i>
                  <span>{error}</span>
                </div>
              )}

              <div className="mt-8 p-6 bg-slate-100 rounded-2xl border border-slate-200">
                <h4 className="text-xs font-bold text-slate-500 uppercase tracking-widest mb-3">Trending in Dallas</h4>
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-slate-600 font-medium">Zip 75201 (Downtown)</span>
                    <span className="text-emerald-500 font-bold">+4.2%</span>
                  </div>
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-slate-600 font-medium">Zip 75034 (Frisco)</span>
                    <span className="text-emerald-500 font-bold">+8.1%</span>
                  </div>
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-slate-600 font-medium">Zip 75208 (Oak Cliff)</span>
                    <span className="text-amber-500 font-bold">+1.5%</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Dashboard / Empty State */}
          <div className="lg:col-span-8">
            {report && prefs ? (
              <ReportDashboard report={report} prefs={prefs} />
            ) : (
              <div className="h-[600px] bg-white rounded-2xl border-2 border-dashed border-slate-200 flex flex-col items-center justify-center text-center p-12">
                <div className="w-24 h-24 bg-slate-50 rounded-full flex items-center justify-center text-slate-300 mb-6">
                  <i className="fa-solid fa-chart-pie text-5xl"></i>
                </div>
                <h3 className="text-2xl font-bold text-slate-800 mb-2">Ready for your intelligence report?</h3>
                <p className="text-slate-500 max-w-md">
                  Input a Dallas zip code on the left to generate a professional-grade market analysis powered by real-time data and AI.
                </p>
                <div className="mt-8 grid grid-cols-2 gap-4">
                  <div className="flex items-center space-x-2 text-xs font-bold text-slate-400 uppercase tracking-wider">
                    <i className="fa-solid fa-check-circle text-blue-500"></i>
                    <span>Real-time Pricing</span>
                  </div>
                  <div className="flex items-center space-x-2 text-xs font-bold text-slate-400 uppercase tracking-wider">
                    <i className="fa-solid fa-check-circle text-blue-500"></i>
                    <span>Investor Yields</span>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </main>
      
      {/* Print Footer */}
      <div className="hidden print-only fixed bottom-0 left-0 right-0 p-8 border-t border-slate-200 text-slate-400 text-xs text-center">
        Report generated by DALLASREALTOR.AI Analysis Bot. Data provided via Gemini 3 & Google Search. Information is for informational purposes only.
      </div>
    </div>
  );
};

export default App;
