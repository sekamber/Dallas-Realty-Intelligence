
export type PropertyType = 'SFH' | 'Condo' | 'Multi-Family';
export type UserPurpose = 'Buy' | 'Sell' | 'Invest';

export interface UserPreferences {
  zipCode: string;
  propertyType: PropertyType;
  purpose: UserPurpose;
  budget: string;
  email: string;
}

export interface MarketData {
  zip: string;
  neighborhoodName: string;
  medianPrice: number;
  priceTrend12m: number; // Percentage
  daysOnMarket: number;
  inventoryLevel: 'Low' | 'Medium' | 'High';
  estimatedRent: number;
  schoolRating: number; // 1-10
  crimeIndex: 'Low' | 'Moderate' | 'High';
  buyerDemandScore: number; // 1-10
  sellerAdvantageScore: number; // 1-10
  appreciationOutlook: string;
  capRate: number;
  riskScore: number;
}

export interface Report {
  marketData: MarketData;
  narrative: string;
  recommendations: string[];
  sources: { title: string; uri: string }[];
}
